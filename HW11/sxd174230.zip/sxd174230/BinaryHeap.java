// Starter code for bounded-size Binary Heap implementation
// Changed signature of heapSort changing <T> to <T extends Comparable<? super T>>
// poll returns null if pq is empty (not false)

package sxd174230;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;

public class BinaryHeap<T extends Comparable<? super T>> {
    T[] pq;
    Comparator<T> comp;
     int currSize;

    // Constructor for building an empty priority queue using natural ordering of T
    public BinaryHeap(T[] q) {
	// Use a lambda expression to create comparator from compareTo
        this(q, (T a, T b) -> a.compareTo(b));
    }
    
    // Constructor for building an empty priority queue with custom comparator
    public BinaryHeap(T[] q, Comparator<T> c) {
	pq = q;
	comp = c;
	currSize = q.length;
        for (int i = parent(currSize - 1); i >= 0; i--) {
            percolateDown(i);
        }
    }
    
    /** Build a priority queue with a given array q, using q[0..n-1].
     *  It is not necessary that n == q.length.
     *  Extra space available can be used to add new elements.
     *  Implement this if solving optional problem.  To be called from heap sort.
     */
    private BinaryHeap(T[] q, Comparator<T> c, int n) {
	pq = q;
	comp = c;
	for (int i = parent(currSize - 1); i >= 0; i--) {
            percolateDown(i);
        }
	// You need to add more code here to build queue
    }

    void print(){
        System.out.println(Arrays.toString(pq));
    }

    public void add(T x) { /* throw exception if pq is full */
        if(currSize == pq.length) throw new RuntimeException("Queue size is full");
        pq[currSize] = x;
        percolateUp(currSize);
        currSize++;
    }

    public boolean offer(T x) { /* return false if pq is full */
	    try{
	        add(x);
	        return true;
        }catch (RuntimeException e){
	        return false;
        }
    }

    public T remove() { /* throw exception if pq is empty */
        if(currSize == 0) throw new RuntimeException("Queue is empty");
        T min = pq[0];
        pq[0] = pq[--currSize];
        percolateDown(0);

	    return min;
    }

    public T poll() { /* return null if pq is empty */
	    try{
	        return remove();
        }catch (RuntimeException e){
	        return null;
        }

    }

    public T peek() { /* return null if pq is empty */
	return pq[0];
    }

    /** pq[i] may violate heap order with parent */
    void percolateUp(int i) { /* to be implemented */
        T x = pq[i];
        while(i>0 && comp.compare(x,pq[parent(i)]) == -1){
            pq[i] = pq[parent(i)];
            i=parent(i);
        }
        pq[i] = x;
    }

    /** pq[i] may violate heap order with children */
    void percolateDown(int i) { /* to be implemented */
        T x = pq[i];
        int c = leftChild(i);
        while(c<=currSize-1){
            if(c < currSize-1 && comp.compare( pq[c],pq[c+1])==1){
                c=c+1;
            }
            if(comp.compare(x,pq[c])== -1) break;
                pq[i] = pq[c];
                i = c;
                c = leftChild(i);

        }
       // System.out.println("Returned");
        pq[i] = x;

    }

    // Assign x to pq[i].  Indexed heap will override this method
    void move(int i, T x) {
	pq[i] = x;
    }

    int parent(int i) {
	return (i-1)/2;
    }

    int leftChild(int i) {
	return 2*i + 1;
    }

// end of functions for team project




// start of optional problem: heap sort (Q2)

    /** Create a heap.  Precondition: none. 
     *  Implement this ifsolving optional problem
     */
    void buildHeap() {
    }

    /* sort array arr[].
       Sorted order depends on comparator used to buid heap.
       min heap ==> descending order
       max heap ==> ascending order
       Implement this for optional problem
     */
    public static<T extends Comparable<? super T>> void heapSort(T[] arr, Comparator<T> c) { /* to be implemented */
    }

    // Sort array using natural ordering
    public static<T extends Comparable<? super T>> void heapSort(T[] arr) {
	heapSort(arr, (T a, T b) -> a.compareTo(b));
    }
// end of optional problem: heap sort (Q2)



// start of optional problem: kth largest element (Q3)

    public void replace(T x) {
	/* TO DO.  Replaces root of binary heap by x if x has higher priority
	     (smaller) than root, and restore heap order.  Otherwise do nothing. 
	   This operation is used in finding largest k elements in a stream.
	   Implement this if solving optional problem.
	 */
    }

    /** Return the kth largest element of stream using custom comparator.
     *  Assume that k is small enough to fit in memory, but the stream is arbitrarily large.
     *  If stream has less than k elements return null.
     */
    public static<T extends Comparable<? super T>> T kthLargest(Iterator<T> stream, int k, Comparator<T> c) {
	return null;
    }

    /** Return the kth largest element of stream using natural ordering.
     *  Assume that k is small enough to fit in memory, but the stream is arbitrarily large.   
     *  If stream has less than k elements return null.
     */
    public static<T extends Comparable<? super T>> T kthLargest(Iterator<T> stream, int k) {
	return kthLargest(stream, k, (T a, T b) -> a.compareTo(b));
    }
// end of optional problem: kth largest element (Q3)

    public static void main(String[] args) {
        int n = 10;
        if (args.length > 0) {
            n = Integer.parseInt((args[0]));
        }
        Integer[] arr = {1,2,3,4,5,6,7,8,9,10};

        BinaryHeap<Integer> heap = new BinaryHeap<Integer>(arr);
        heap.print();
        Scanner in = new Scanner(System.in);
        whileloop:
        while (in.hasNext()) {
            int com = in.nextInt();
            switch (com) {
                case 1: // Add element
                    System.out.println("Enter element: ");
                    heap.add(in.nextInt());
                    heap.print();
                    break;
                case 2: // Offer element
                    System.out.println("Enter element: ");
                    System.out.println(heap.offer(in.nextInt()));
                    heap.print();
                    break;
                case 3: // Remove element
                    heap.remove();
                    heap.print();
                    break;
                case 4: // Poll element
                    heap.poll();
                    heap.print();
                    break;
                case 5: // Peak element
                    System.out.println(heap.peek());
                    break;
                default:
                    break whileloop;
            }
        }
    }

}
