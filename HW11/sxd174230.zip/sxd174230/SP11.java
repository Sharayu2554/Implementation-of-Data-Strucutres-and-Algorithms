/**
 * @author Punit Bhalla and Vineet Vats
 * <p>
 * find K largest elements from an array using following methods:
 * Choice 1. Select Algorithm
 * Choice 2. Priority Queue
 * <p>
 * Compares the performance for both the methods.
 */

package sxd174230;


import java.util.Random;

/**
 * <p>Class to compare run time of Select algorithm and Priority Queue
 * to identify which one is better to find k largest element from an array of n elements</p>
 * @author Sharayu Mantri and Spandan Dey
 */

public class SP11 {

    /**
     * threshold: value of n on which insertion sort is to be executed
     * index: required to print K largest elements using
     * numTrials: no of times each algorithm is run to calculate avg performance
     * priotityQueue: a priority queue to be used as binary heap
     */
    private static int th = 5;
    private static int index;
    public static int numberOfTrials = 5    ;
    private static BinaryHeap priotityQueue;

    /**
     * This function finds the k largest numbers in an array using priority queue algorithm
     *
     * @param arr array of integers
     * @param k   number of largest elements to be retrieved
     */
    public static void selectKLargestNumbers(int[] arr, int k) {
        Integer[] tmp = new Integer[k];
        for (int i = 0; i < k; i++) {
            tmp[i] = Integer.valueOf(arr[i]);
        }
        priotityQueue = new BinaryHeap(tmp);
        for (int i = k; i < arr.length; i++) {
            Integer integer = arr[i];
            if (integer.intValue()>((Integer) priotityQueue.peek()).intValue()) {
                priotityQueue.move(0, integer);
                priotityQueue.percolateDown(0);
            }
        }
    }

    /**
     * This function finds the k largest numbers in an array using select algorithm
     *
     * @param arr array of integers
     * @param k   number of largest elements to be retrieved
     *            result is stored in arr[arr.length-k... arr.length-1]
     */
    public static void select(int[] arr, int k) {
        index = select(arr, 0, arr.length, k);
    }

    /**
     * Generic Helper function to find k largest numbers from an array
     *
     * @param arr array of integers from which K largest elements to be found
     * @param p   start position of array to search from
     * @param n   number of elements in an array
     * @param k   : number of largest elements to be retrieved
     * @return the index which then can be used to retrieve k largest elements from arr
     */
    private static int select(int[] arr, int p, int n, int k) {
        if (n < th) {
            insertionSort(arr, p, p + n - 1);
            return p + n - k;
        } else {
            int q = randomizedPartition(arr, p, p + n - 1);
            int left = q - p;
            int right = n - left - 1;
            if (right >= k) {
                return select(arr, q + 1, right, k);
            } else if (right + 1 == k) return q;
            else {
                return select(arr, p, left, k - right - 1);
            }
        }
    }

    /**
     * This function finds the pivot element for partitioning the array
     *
     * @param arr array of integers
     * @param p   start position of array to be considered for partitioning
     * @param r   end position of array to be considered for partitioning
     * @return pivot index
     */
    private static int randomizedPartition(int[] arr, int p, int r) {
        Random random = new Random();
        int i = random.nextInt(r - p) + p;
        swap(arr, i, r);
        return partition(arr, p, r);
    }

    /**
     * This function finds the partition's index
     *
     * @param arr array of integers
     * @param p   start position of the array
     * @param r   end position of the array
     * @return partition's index
     */
    private static int partition(int[] arr, int p, int r) {
        int i = p - 1;
        int x = arr[r];
        for (int j = p; j < r; j++) {
            if (arr[j] <= x) {
                i = i + 1;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, r);
        return i + 1;
    }

    /**
     * This function swaps the elements within an array
     *
     * @param arr array of integers
     * @param i   index to be swapped
     * @param j   index with which arr[i] needs to be swapped
     */
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    /**
     * Insertion sort method
     *
     * @param arr array of integers
     * @param p   start index of the array where sorting to be done
     * @param r   end index of the array where sorting to be done
     */
    private static void insertionSort(int[] arr, int p, int r) {
        int temp;
        int j;
        for (int i = p + 1; i <= r; i++) {
            temp = arr[i];
            j = i - 1;
            while (j >= p && arr[j] > temp) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = temp;
        }
    }

    /**
     * Helper method to shuffle the array
     *
     * @param arr  array of integers
     * @param first start index of array
     * @param last   end index of array
     */
    private static void shuffle(int[] arr, int first, int last) {
        int n = last - first + 1;
        for (int i = 1; i < n; i++) {
            int j = new Random().nextInt(i);
            swap(arr, i + first, j + first);
        }
    }


    /**
     * This function shuffles the array
     *
     * @param arr array of integers
     */
    private static void shuffle(int[] arr) {
        shuffle(arr, 0, arr.length - 1);
    }

    /**
     * Method to print the array
     *
     * @param arr     array of integers
     * @param message message to be printed
     */
    public static <T> void printArray(int[] arr, String message) {
        printArray(arr, 0, arr.length - 1, message);
    }

    /**
     * This functions prints the elements of a sub array
     *
     * @param arr     array of integers
     * @param from    from index for start of subarray
     * @param to      to index for start of subarray
     * @param message message to be printed
     */
    public static <T> void printArray(int[] arr, int from, int to, String message) {
        System.out.print(message);
        for (int i = from; i <= to; i++) {
            System.out.print(" " + arr[i]);
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int n = 256000000;
        int k = (int) Math.ceil(n / 2.0);
        int choice = 1;// + new Random().nextInt(2);
        if (args.length > 0) {
            n = Integer.parseInt(args[0]);
        }
        if (args.length > 1) {
            choice = Integer.parseInt(args[1]);
        }
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = i;
        }
        Timer timer;
        switch (choice) {
            case 1:// Select Algorithm
                timer = new Timer();
                for (int i = 0; i < numberOfTrials; i++) {
                    shuffle(arr);
                    select(arr, k);
                }
               // printArray(arr, index, n - 1, "K largest Numbers");
                timer.end();
                timer.scale(numberOfTrials);
                System.out.println("Choice: " + choice + "\n" + timer);
                break;
            case 2://Priority Queue Method
                timer = new Timer();
                for (int i = 0; i < numberOfTrials; i++) {
                    shuffle(arr);
                    selectKLargestNumbers(arr, k);
                }
                //printArray(arr, index, n - 1, "K largest Numbers");
                timer.end();
                timer.scale(numberOfTrials);
                //priotityQueue.print();
//                System.out.println("K Largest Numbers using Priority Queue: ");
//                while (priotityQueue.currSize != 0) {
//                    System.out.print(priotityQueue.poll() + " ");
//                }
                System.out.println("\nChoice: " + choice + "\n" + timer);
                break;
        }

    }

}
