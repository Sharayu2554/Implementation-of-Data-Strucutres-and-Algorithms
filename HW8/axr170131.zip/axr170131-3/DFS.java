
/** SP 8: Depth-first search(DFS)
 *Authors: Akshaya Ramaswamy,Sharayu Mantri
 */

package rbk;
import rbk.Graph.Vertex;
import rbk.Graph.Edge;
import rbk.Graph.GraphAlgorithm;
import rbk.Graph.Factory;
import rbk.Graph.Timer;
import rbk.scene.effect.Effect;

import java.io.File;
import java.util.List;
import java.util.LinkedList;
import java.util.Scanner;

public class DFS extends GraphAlgorithm<DFS.DFSVertex> {

    //Class to store information about vertices using DFS
    public static class DFSVertex implements Factory {
        int cno;
        Vertex parent;

        enum colors{
            WHITE,GRAY,BLACK;
        }
        colors color; //Color to indicate if the vertices have been visited or not.

        public DFSVertex(Vertex u) {
            parent=null;
            color=colors.WHITE;

        }
        public DFSVertex make(Vertex u) { return new DFSVertex(u); }
    }


    List<Vertex> finishList;
    boolean isCycle=false;//To check if a cycle exists

    public DFS(Graph g) {
        super(g, new DFSVertex(null));
    }

    //Runs Depth-first algorithm on graph g.
    public static DFS depthFirstSearch(Graph g) {
        DFS d=new DFS(g);
        d.dfs();
        return d;
    }

    //Recursive function used by dfs() to visit all vertices incident on it.
    public void DFS_VISIT(Vertex u){

        get(u).color=DFSVertex.colors.GRAY;
        for(Edge e:g.incident(u)){
            Vertex v=e.otherEnd(u);
            if(get(v).color==DFSVertex.colors.WHITE){
                get(v).parent=u;
                DFS_VISIT(v);
            }
            else if(get(v).color==DFSVertex.colors.GRAY){
                isCycle=true;
            }
        }
        finishList.add(0,u);

        get(u).color=DFSVertex.colors.BLACK;
    }

    //Function to perform Depth-first search.
    public void dfs(){

        finishList=new LinkedList();
        for(Vertex u:g){
            get(u).parent=null;
            get(u).color=DFSVertex.colors.WHITE;
        }

        for(Vertex u:g){
            if(get(u).color==DFSVertex.colors.WHITE){
                DFS_VISIT(u);
            }
        }
    }

    // Member function to find topological order
    public List<Vertex> topologicalOrder1() {
        dfs();
        return finishList;
    }



    // Find the number of connected components of the graph g by running dfs.
    // Enter the component number of each vertex u in u.cno.
    // Note that the graph g is available as a class field via GraphAlgorithm.
    public int connectedComponents() {
        return 0;
    }

    // After running the connected components algorithm, the component no of each vertex can be queried.
    public int cno(Vertex u) {
        return get(u).cno;
    }



    // Finds the topological ordering of the DAG. Returns null if g is not a DAG.
    public static List<Vertex> topologicalOrder1(Graph g) {
        DFS d = new DFS(g);
        if(d.isCycle)return null;
        return d.topologicalOrder1();
    }

    // Find topological oder of a DAG using the second algorithm. Returns null if g is not a DAG.
    public static List<Vertex> topologicalOrder2(Graph g) {
        return null;
    }

    public static void main(String[] args) throws Exception {
        String string = "7 8   1 2 2   1 3 3   2 4 5   3 4 4   4 5 1   5 1 7   6 7 1   7 6 1 0";
        Scanner in;
        // If there is a command line argument, use it as file from which
        // input is read, otherwise use input from string.
        in = args.length > 0 ? new Scanner(new File(args[0])) : new Scanner(string);

        // Read graph from input
        Graph g = Graph.readGraph(in);
        g.printGraph(false);

        DFS d = new DFS(g);
        int numcc = d.connectedComponents();
        System.out.println("Number of components: " + numcc + "\nu\tcno");
        for(Vertex u: g) {
            System.out.println(u + "\t" + d.cno(u));
        }
        System.out.println(topologicalOrder1(g));
    }
}
