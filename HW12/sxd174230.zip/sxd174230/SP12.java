/**
 * author: Punit Bhalla and Vineet Vats
 */
package sxd174230;

import rbk.BFSOO;
import rbk.Graph;
import rbk.Graph.Vertex;
import java.io.File;
import java.util.Scanner;


/**
 * @author Sharayu Mantri and Spandan Dey
 * <p>Class used to calculate diameter of a tree</p>
 */
public class SP12 {

    /**
     * <p>Root Node of the tree</p>
     */
    private Vertex root;

    /**
     *
      * @return Root node of the tree
     */
    public Vertex getRoot() {
        return root;
    }

    /**
     *
     * @param root Root node of a tree
     */
    public void setRoot(Vertex root) {
        this.root = root;
    }

    /**
     * <p>Method to calculate the diameter of a tree or DAG</p>
     * @param g A DAG or a tree which basically is a DAG
     * @return diameter of a DAG or Tree
     */
     int calculateDiameter(Graph g) {
        if(g.size()==0) return 0;
        // set the Root node
        setRoot(g.getVertex(g.size()));

        // Node with maximumDistance from root Node
        Vertex nodeWithMaxDistance = null;
        int dist = Integer.MIN_VALUE;

        // runs bfs with root vertex of this class as starting point
        BFSOO bfsoo = BFSOO.breadthFirstSearch(g, getRoot());

        for (Vertex u : g) {
            if (bfsoo.getDistance(u) > dist) {
                nodeWithMaxDistance = u;
                dist = bfsoo.getDistance(u);
            }
        }

        // Assigns Max node as root vertex for second BFS run
        setRoot(nodeWithMaxDistance);

        //Second BFS call with new Root which is the node with max distance from original root
        bfsoo = BFSOO.breadthFirstSearch(g, getRoot());

        dist = Integer.MIN_VALUE;
        for (Vertex u : g) {
            if (bfsoo.getDistance(u) > dist) {
                nodeWithMaxDistance = u;
                dist = bfsoo.getDistance(u);
            }
        }
        return bfsoo.getDistance(nodeWithMaxDistance);
    }

    public static void main(String[] args) throws Exception {
        String string = "10 9   1 2 2   1 3 3   2 4 5   2 5 4   3 6 1   3 7 1   4 8 1   7 9 1   7 10 1";
        //String string = "7 6   1 2 2   1 3 3   2 4 5   2 5 4   4 6 1   4 7 1";
        Scanner in;
        // If there is a command line argument, use it as file from which
        // input is read, otherwise use input from string.
        in = args.length > 0 ? new Scanner(new File(args[0])) : new Scanner(string);
        // Read graph from input
        Graph g = Graph.readGraph(in, false);
        g.printGraph(false);

        SP12 sp12 = new SP12();

        int diameter = sp12.calculateDiameter(g);
        System.out.println("Diameter of tree: " + diameter);
    }
}
