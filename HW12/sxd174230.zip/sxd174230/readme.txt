Steps to compile and run the code:

There are basically two ways by which you can run this code:
1. Using Command Line
2. Using IDE

Note: First of all extract the folder sxd174230 from zip file "sxd174230.zip".

1. Steps to run the code using Command Line:
 Step1: Copy the package folder  i.e. sxd174230 to any location on your PC.
 Step2: Open terminal or command line interface and go to the parent folder of the package folder using cd command.
 Step3: Compile SP12.java file using the following command:
 		$ javac sxd174230/SP12.java

	    
2. Steps to run the code using IDE:
 Step1: Create a simple java project. For example if you are using eclipse then go to File->New->Project->Java Project.
 Step2: Copy the package folder sxd174230 under root folder.
 Step3: Right click on the project name and build the project.
 Step4: Right click on the project name, go to "Run as" option and then click on "Java Application".
 Step5: Select SP12 from the available  files to execute the code.

