package axr170131;

/** Assignment SP10
 *  Authors: Akshaya Ramaswamy, Sharayu Mantri
 */

import rbk.Graph.Vertex;
import rbk.Graph.Edge;
import rbk.Graph.GraphAlgorithm;
import rbk.Graph.Factory;

import java.io.File;
import java.util.*;

public class DFS extends GraphAlgorithm<DFS.DFSVertex> {
    private static boolean flag;

    //Class to store information about vertices using DFS
    public static class DFSVertex implements Factory {
        int cno;
        Vertex parent;
        //Color to indicate if the vertices have been visited or not.
        enum Colors {
            WHITE,GRAY,BLACK;
        }
        Colors color;
        int top;

        public DFSVertex(Vertex u) {
            parent=null;
            color=Colors.WHITE;
            top=0;
        }
        public DFSVertex make(Vertex u) { return new DFSVertex(u); }
    }

    List<Vertex> finishList;
    int cn=0;

    public DFS(Graph g) {
        super(g, new DFSVertex(null));
        flag=false;
    }

    //Runs Depth-first algorithm on graph g.
    public static DFS depthFirstSearch(Graph g) {
        DFS d=new DFS(g);
        d.dfs(g);
        return d;
    }

    public static DFS stronglyConnectedComponents(Graph g) {
        DFS d=new DFS(g);
        d.dfs(g);
        List<Vertex> list=d.finishList;
        //Reversing the graph
        g.reverseGraph();
        flag=true;
        d.dfs(list);
        //To restore the original graph
        g.reverseGraph();
        return d;
    }

    //Recursive function used by dfs() to visit all vertices incident on it.
    public void dfsVisit(Vertex u, int cn){

        get(u).color=DFSVertex.Colors.GRAY;
        get(u).cno=cn;
        for(Edge e:g.incident(u)){
            Vertex v=e.otherEnd(u);
            if(get(v).color==DFSVertex.Colors.WHITE){
                get(v).parent=u;
                dfsVisit(v,cn);
            }
        }
        finishList.add(0,u);
        //The color is set to black if all its adjacent vertices have been visited
        get(u).color=DFSVertex.Colors.BLACK;
    }

    //Function to perform Depth-first search.
    public void dfs(Iterable<Vertex> iterable){

        finishList=new LinkedList();

        //Marks all the vertices not visited
        for (Vertex u:iterable) {
            get(u).parent=null;
            get(u).color=DFSVertex.Colors.WHITE;
        }

        for(Vertex u:g){
            if(get(u).color==DFSVertex.Colors.WHITE){
               if(flag==true)
                dfsVisit(u,++cn);//Increment the component number incase of a new component.
               else{
                   dfsVisit(u,cn);
               }

            }
        }
    }


    // After running the connected components algorithm, the component no of each vertex can be queried.
    public int cno(Vertex u) {
        return get(u).cno;
    }

}